 
import UIKit

class Speaker: UITableViewCell {

    @IBOutlet weak var titleCell: UILabel!
    @IBOutlet weak var imageCell: UIImageView!
    
    
    func setData(data:String) {
        
       // self.imageCell.image = UIImage(named: data)
        self.titleCell.text = data
        
    }
    
}
