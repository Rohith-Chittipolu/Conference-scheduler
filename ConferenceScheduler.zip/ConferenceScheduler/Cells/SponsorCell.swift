 
import UIKit

class SponsorCell: UITableViewCell {

    @IBOutlet weak var sponsorDetails: UILabel!
    @IBOutlet weak var sponsorName: UILabel!
    
    
    
}
