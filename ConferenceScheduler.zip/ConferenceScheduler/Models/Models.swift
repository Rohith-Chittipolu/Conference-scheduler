import Foundation
import FirebaseFirestoreSwift

struct ConferencesModel: Codable {
    
    var name, key, imageUrl: String
    
}

 


struct EventModel: Codable {
    
    var eventName,aboutSpeaker, date,eventDescription,imageUrl,location , speaker, speakerkey ,conferenceId, time,key:String
    
}

 
