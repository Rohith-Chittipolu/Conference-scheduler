const express = require("express");

const router = express.Router();

const { signin, signup } = require("../controllers/admin");

const { isLoggedIn, isAdmin } = require("../middleware/auth");

router.post("/signup", signup);

router.post("/signin", signin);

router.post("/test", isLoggedIn, isAdmin, (req, res) => {
  console.log("success");
  res.json({ status: "ok" });
});

module.exports = router;
