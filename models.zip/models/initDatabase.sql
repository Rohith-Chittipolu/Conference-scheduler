SELECT 'CREATE DATABASE nursingconference' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'nursingconference')\gexec

\c nursingconference;

drop type user_types
CREATE TYPE USER_TYPES AS ENUM ('admin', 'regular');

DROP TABLE users;
CREATE TABLE users (
  user_id SERIAL PRIMARY KEY,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(65) NOT NULL,
  user_type USER_TYPES DEFAULT('regular') NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100)
);
