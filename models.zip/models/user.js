const connection = require("../config/database");

const insertNewUser = async ({ email, password, first_name, last_name }) => {
  const query = `
    INSERT INTO users (email, password, first_name, last_name)
        VALUES ($1, $2, $3, $4);
  `;
  const res = await connection.query(query, [
    email,
    password,
    first_name,
    last_name,
  ]);
  return res;
};

const insertNewAdmin = async ({ email, password, first_name, last_name }) => {
  const query = `
    INSERT INTO users (email, password, first_name, last_name, user_type)
        VALUES ($1, $2, $3, $4, $5);
  `;
  const res = await connection.query(query, [
    email,
    password,
    first_name,
    last_name,
    "admin",
  ]);
  return res;
};

const findUser = async ({ email }) => {
  const query = `
    SELECT email, password, user_type FROM users WHERE email = $1
    `;
  const res = await connection.query(query, [email]);
  if (res.rowCount === 1) {
    return res.rows[0];
  }
  return {};
};

module.exports = {
  insertNewUser,
  insertNewAdmin,
  findUser,
};
