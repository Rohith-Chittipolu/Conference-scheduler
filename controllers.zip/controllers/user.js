const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const { insertNewUser, findUser } = require("../models/user");

const JWT_SECRET = process.env.JWT_SECRET;

const signup = async (req, res) => {
  const { email, password, first_name, last_name } = req.body;

  const hash = await bcrypt.hash(password, 10);
  await insertNewUser({ email, password: hash, first_name, last_name });
  res.json({ message: "ok" });
};

const signin = async (req, res) => {
  const { email, password } = req.body;

  const user = await findUser({ email });

  if (user.password && (await bcrypt.compare(password, user.password))) {
    const token = jwt.sign({ email: user.email }, JWT_SECRET, {
      expiresIn: "1d",
    });
    res.header("Authorization", `Bearer ${token}`);
    return res.json({
      message: "ok",
    });
  } else {
    return res.json({
      message: "invalid email or password",
    });
  }
};

module.exports = {
  signup,
  signin,
};
