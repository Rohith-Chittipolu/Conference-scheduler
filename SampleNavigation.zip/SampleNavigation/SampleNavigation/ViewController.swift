//
//  ViewController.swift
//  SampleNavigation
//
//  Created by Sunkireddy,Aakanksha Reddy on 10/2/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

