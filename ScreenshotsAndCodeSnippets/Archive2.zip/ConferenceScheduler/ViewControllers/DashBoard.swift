import UIKit

class DashBoard: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var topTitle: UILabel!
    @IBOutlet weak var noEventImage: UIImageView!
    @IBOutlet weak var noConferenceLabel: UILabel!
    @IBOutlet weak var eventView: UIView!
    @IBOutlet weak var eventImageView: UIImageView!
    var haveEvents = false
    var conferenceId = ""
    var evets = [EventModel]()
    @IBOutlet weak var eventName: UILabel!
    
    func showEvents(){
        
        if(haveEvents) {
            
            self.topTitle.isHidden = false
            self.noEventImage.isHidden = true
            noConferenceLabel.isHidden = true
            self.eventView.isHidden = false
            
        }else {
            self.topTitle.isHidden = true
            self.noEventImage.isHidden = false
            noConferenceLabel.isHidden = false
            self.eventView.isHidden = true
        }
    }
     
    
    override func viewDidLoad() {

    
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.showsVerticalScrollIndicator = false
        
        if let button = view.viewWithTag(20) as? UIButton {
            button.addTarget(self, action: #selector(addEventButtonClick), for: .touchUpInside)
        }
        
        self.showEvents()
        
        self.tableView.registerCells([EventCell.self])
        
        FireStoreManager.shared.getConferences { confrences in
            
            if(confrences.count == 0) {
                self.haveEvents = false
                self.showEvents()
                self.conferenceId = ""
            }else {
                self.haveEvents = true
                self.showEvents()
                self.eventName.text = confrences.first?.name ?? ""
                self.conferenceId = confrences.first?.key ?? ""
                let eventImageUrl = confrences.first?.imageUrl ?? ""
                
                if(eventImageUrl.count > 5) {
                  
                    let imageURL = URL(string: eventImageUrl)
                    let imageData = try? Data(contentsOf: imageURL!)
                    if let imageData = imageData {
                        let image = UIImage(data: imageData)
                        self.eventImageView.image = image
                    }
                }
                
                self.getEvents()
                
            }
        }
    }
    
    
    func getEvents() {

        if(conferenceId == "") { // empty list and realaod data
            
            self.evets.removeAll()
            self.tableView.reloadData()
        }else {
            
            
            FireStoreManager.shared.getEvents(conferenceId: conferenceId) { evets in
                self.evets = evets
                self.tableView.reloadData()
            }
        }
        
       
    }
    
    @objc func addEventButtonClick() {
       
        let story = UIStoryboard(name: "Main", bundle:nil)
        let vc = story.instantiateViewController(withIdentifier: "CreateEventVC") as! CreateEventVC
        vc.conferenceId = conferenceId
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
        
        
    }

    
    @IBAction func createConfrence(_ sender: Any) {
        
        let story = UIStoryboard(name: "Main", bundle:nil)
        let vc = story.instantiateViewController(withIdentifier: "CreateConferenceVC") as! CreateConferenceVC
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
        
    }

}



extension DashBoard: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.evets.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: EventCell.self), for: indexPath) as! EventCell
        
        cell.setData(evet: evets[indexPath.row])
        
        if(UserDefaultsManager.shared.getUserType() == .STUDENT) {
            cell.addButton.isHidden = false
            cell.addButton.tag = indexPath.row
            cell.addButton.addTarget(self, action: #selector(self.addToSchedule(_:)), for: .touchUpInside)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        DispatchQueue.main.async {
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "EventDetailsVC") as! EventDetailsVC
            vc.modalPresentationStyle = .popover
            vc.event = self.evets[indexPath.row]
            self.present(vc, animated: true)
            
             
        }
           
         
        
    }
    

    
    @objc func addToSchedule(_ sender: UIButton) {
        let row = sender.tag
        let event = evets[row]
 
        
    }
    
    
}
