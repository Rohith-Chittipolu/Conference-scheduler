import UIKit


class CreateConferenceVC: UIViewController {

    @IBOutlet weak var selectedImage: UIImageView!
    @IBOutlet weak var conferenceName: UITextField!
    var photoSelected = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
 
    @IBAction func onPhoto(_ sender: Any) {
        self.view.endEditing(true)
        let sourceType: UIImagePickerController.SourceType = .photoLibrary

        presentImagePickerController(sourceType: sourceType) { (selectedImage) in
            if let image = selectedImage {
                self.selectedImage.image = image
                self.photoSelected = true
            }
        }
    }
    @IBAction func onCreateConference(_ sender: Any) {
        
        self.view.endEditing(true)
        
        if(self.conferenceName.text!.isEmpty) {
            showAlert(message: "Please enter conference Name")
            return
        }
        
        if(!photoSelected) {
            showAlert(message: "Please add conference image")
            return
        }
        
        FireStoreManager.shared.saveImage(image: selectedImage.image!) { imageUrl in
             
            FireStoreManager.shared.saveConference(name: self.conferenceName.text!, url: imageUrl) {
                 
                self.dismiss(animated: true)
            }
        }
        
    }
    
   
    
}
