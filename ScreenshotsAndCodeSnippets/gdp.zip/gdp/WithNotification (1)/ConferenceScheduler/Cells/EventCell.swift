 
import UIKit

class EventCell: UITableViewCell {

    @IBOutlet weak var eventName: UILabel!
    @IBOutlet weak var eventDate: UILabel!
    @IBOutlet weak var addButton: UIButton!
    
    func setData(evet : EventModel ) {
        
        self.eventName.text = evet.eventName
        self.eventDate.text = evet.date + " " + evet.time
    }
}
