 
import UIKit

class EventCell: UITableViewCell {

    @IBOutlet weak var eventName: UILabel!
    @IBOutlet weak var eventDate: UILabel!
    @IBOutlet weak var addButton: UIButton!
    
    func setData(evet : EventModel ) {
        self.eventName.text = evet.eventName
        self.eventDate.text =  getDateTime(date: evet.eventTime ?? Date())
    }
}


func getDateTime(date:Date)->String{
    let date = Date()
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd MMMM YYYY hh:mm a"
    let dateString = dateFormatter.string(from: date)
    return dateString
}
