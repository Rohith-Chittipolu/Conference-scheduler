import UIKit
import Firebase

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let tabBar = UITabBar.appearance()
        tabBar.tintColor = AppColors.primary

        IQKeyboardManager.shared.enable = true
        UINavigationBar.appearance().tintColor = .black

        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
        }
        NotificationManager.shared.registerForRemoteNotifications()

        return true
    }

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let token = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
        print("APNS token: \(token)")

        Messaging.messaging().apnsToken = deviceToken
        Messaging.messaging().token { fcmToken, error in
            if let error = error {
                print("Error getting FCM token: \(error.localizedDescription)")
            } else if let fcmToken = fcmToken {
                print("FCM token: \(fcmToken)")
            }
        }
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Failed to register for remote notifications: \(error.localizedDescription)")
    }

}
