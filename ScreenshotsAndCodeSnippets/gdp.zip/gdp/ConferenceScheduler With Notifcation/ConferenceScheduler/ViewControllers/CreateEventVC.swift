
import UIKit

class CreateEventVC: UIViewController {

    @IBOutlet weak var breakOut: UIButton!
    @IBOutlet weak var keyNote: UIButton!
    var data = [SpeakersModel]()
    var selectedSpaker : SpeakersModel!
    var keyNoteSeleted = true
    @IBOutlet weak var surveyLink: UITextField!
    var conferenceId = ""
    @IBOutlet weak var eventName: UITextField!
    @IBOutlet weak var eventDescription: UITextField!
    @IBOutlet weak var speaker: UITextField!
    @IBOutlet weak var aboutSpeaker: UITextField!
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var dateTime: UILabel!
    @IBOutlet weak var selectedImage: UIImageView!
    let globalPicker = GlobalPicker()
    let datePicker = UIDatePicker()
    var photoSelected = false
    var dateSelected = false
    
    
    override func viewDidLoad() {
        self.keyNote.layer.cornerRadius = 7.5
        self.breakOut.layer.cornerRadius = 7.5
        self.breakOut.layer.borderWidth = 1
        self.keyNote.layer.borderWidth = 1
        setRadioButton()
    }
    
    @IBAction func onKeyNote(_ sender: Any) {
        keyNoteSeleted = true
        setRadioButton()
    }
    
    @IBAction func onBreakOut(_ sender: Any) {
        keyNoteSeleted = false
        setRadioButton()
    }
    
    
    func setRadioButton() {
        
        if(keyNoteSeleted) {
            
            self.keyNote.backgroundColor = AppColors.primary
            self.keyNote.layer.borderColor = AppColors.primary.cgColor
            self.breakOut.backgroundColor = UIColor.clear
            self.breakOut.layer.borderColor = UIColor.darkGray.cgColor
         
            
        }else {
           
            self.breakOut.backgroundColor = AppColors.primary
            self.breakOut.layer.borderColor = AppColors.primary.cgColor
            self.keyNote.backgroundColor = UIColor.clear
            self.keyNote.layer.borderColor = UIColor.darkGray.cgColor
            
        }
    }
   
 
    @IBAction func onDateAndTime(_ sender: Any) {
        
        let vc = GlobalDatePickerVC(nibName: "GlobalDatePickerVC", bundle: nil)
          vc.isModalInPresentation = true
        self.present(vc, animated: true, completion: nil)
        vc.modalPresentationStyle = .overCurrentContext
        vc.completionHandler = { [self] date,selectedDate in
            dateTime.text = selectedDate
            dateSelected = true
        }
        
    }
    @IBAction func onAddSpeaker(_ sender: Any) {
    
        self.view.endEditing(true)
        
        FireStoreManager.shared.getSpeakersNoListen { speakers in
            self.data = speakers
            self.openSpeakerSelector()
            
        }
    }
    
    func openSpeakerSelector() {
        
        globalPicker.stringArray = self.data.map{$0.name}
        
        globalPicker.modalPresentationStyle = .overCurrentContext
        
        globalPicker.onDone = { index in
            let data =  self.data[index]
            self.speaker.text = data.name
            self.aboutSpeaker.text = data.details
            self.selectedSpaker = data
        }
       
        present(globalPicker, animated: true, completion: nil)
    }
    
    @IBAction func onPhoto(_ sender: Any) {
        self.view.endEditing(true)
        let sourceType: UIImagePickerController.SourceType = .photoLibrary

        presentImagePickerController(sourceType: sourceType) { (selectedImage) in
            
            if let image = selectedImage {
                self.selectedImage.image = image
                self.photoSelected = true
            }
        }
    }
    @IBAction func onCreateEvent(_ sender: Any) {
      
        self.view.endEditing(true)
        
        if(self.eventName.text!.isEmpty) {
            showAlert(message: "Please enter event name")
            return
        }
        
        if(self.eventDescription.text!.isEmpty) {
            showAlert(message: "Please enter event description")
            return
        }
        
        if(self.speaker.text!.isEmpty) {
            showAlert(message: "Please enter speaker name")
            return
        }
        
        if(self.aboutSpeaker.text!.isEmpty) {
            showAlert(message: "Please enter speaker details")
            return
        }
        
        if(self.location.text!.isEmpty) {
            showAlert(message: "Please enter event location")
            return
        }
        
        if(!dateSelected) {
            showAlert(message: "Please enter date")
            return
        }
        
        if(!photoSelected) {
            showAlert(message: "Please add event image")
            return
        }
        
        FireStoreManager.shared.saveImage(image: selectedImage.image!) { imageUrl in
             
            let dateTime = self.dateTime.text!.components(separatedBy: " ")
            
            let date = dateTime[0]
            let time = dateTime[1]
            
            var type = ""
            
            if(self.keyNoteSeleted) {
                type = "KeyNote"
            }else {
                type = "BreakOut"
            }
          
            FireStoreManager.shared.createEvent(speakerKey: self.selectedSpaker.key, conferenceId: self.conferenceId, eventName: self.eventName.text!, eventDescription: self.eventDescription.text!, speaker: self.speaker.text!, aboutSpeaker: self.aboutSpeaker.text!, location: self.location.text!, date: date, time: time, imageUrl: imageUrl, type: type, surveyLink: self.surveyLink.text ?? "") {
                self.dismiss(animated: true)
            }
            

        }
    }
    
    
}
