 
import UIKit

  
class SpeakerListVC: UIViewController {

    var data = [SpeakersModel]()
    
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.registerCells([Speaker.self])
        
        if(UserDefaultsManager.shared.getUserType() == .STUDENT || UserDefaultsManager.shared.getUserType() == .SUPER_ADMIN ) {
            addButton.isHidden = true
            
        }
        
        self.getSpeakers()
   
    }
    
    func getSpeakers() {
        
        FireStoreManager.shared.getSpeakers { speakers in
            
            if(speakers.isEmpty) {
                showAlertAnyWhere(message: "There is no Speakers, please add some Speakers")
            }
            
            self.data = speakers
            self.tableView.reloadData()
        }
    }
    
}



extension SpeakerListVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: Speaker.self), for: indexPath) as! Speaker
        cell.setData(data: data[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
        speakerData = self.data[indexPath.row]
    
        let speakerDetailsPopupViewController = SpeakerDetailsPopupViewController()
        speakerDetailsPopupViewController.modalPresentationStyle = .overFullScreen
        speakerDetailsPopupViewController.modalTransitionStyle = .crossDissolve
        present(speakerDetailsPopupViewController, animated: true, completion: nil)
        
    }
    
}
