import UIKit
import AVFoundation

class CreateConferenceVC: UIViewController {

    @IBOutlet weak var selectedImage: UIImageView!
    @IBOutlet weak var conferenceName: UITextField!
    var photoSelected = false
    
    
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var playerView2: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let path = Bundle.main.path(forResource: "EventVideo", ofType:"mp4") else {
                    debugPrint("video.mp4 not found")
                    return
                }
        let player = AVPlayer(url: URL(fileURLWithPath: path))
        self.playerView2.clipsToBounds = true
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = self.playerView2.bounds
        playerLayer.videoGravity = .resizeAspectFill
        self.playerView2.layer.addSublayer(playerLayer)
        player.play()
        

    }
 
    @IBAction func onPhoto(_ sender: Any) {
        self.view.endEditing(true)
        let sourceType: UIImagePickerController.SourceType = .photoLibrary

        presentImagePickerController(sourceType: sourceType) { (selectedImage) in
            if let image = selectedImage {
                self.selectedImage.image = image
                self.photoSelected = true
            }
        }
    }
    @IBAction func onCreateConference(_ sender: Any) {
        
        self.view.endEditing(true)
        
        if(self.conferenceName.text!.isEmpty) {
            showAlert(message: "Please enter conference Name")
            return
        }
        
        if(!photoSelected) {
            showAlert(message: "Please add conference image")
            return
        }
        
        FireStoreManager.shared.saveImage(image: selectedImage.image!) { imageUrl in
             
            FireStoreManager.shared.saveConference(name: self.conferenceName.text!, url: imageUrl) {
                 
                self.dismiss(animated: true)
            }
        }
        
    }
    
   
    
}
