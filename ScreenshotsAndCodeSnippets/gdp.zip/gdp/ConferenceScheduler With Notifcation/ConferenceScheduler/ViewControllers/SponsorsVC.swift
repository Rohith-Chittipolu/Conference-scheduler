 
import UIKit

let sponsorTypes = ["Diamond Sponsor", "Gold Sponsor", "Silver Sponsor"]


class SponsorsVC: UIViewController {

    var data = [SponsorModel]()
    var allData:[[SponsorModel]] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var addButton: UIButton!
    
 
    override func viewDidLoad() {
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.registerCells([SponsorCell.self])
        tableView.backgroundView = nil
        
        if(UserDefaultsManager.shared.getUserType() == .STUDENT || UserDefaultsManager.shared.getUserType() == .SUPER_ADMIN ) {
            addButton.isHidden = true
            
        }
        
        self.getSponsors()
        
    }
    
    func getSponsors() {
        
        FireStoreManager.shared.getSposors { sponsors in
            
            if(sponsors.isEmpty) {
                showAlertAnyWhere(message: "There is no Sponsors, please add some Sponsors")
            }
            self.data = sponsors
            self.setData()
            self.tableView.reloadData()
        }
    }
    
    func setData() {
        
        var mData:[[SponsorModel]] = []
        
        for _ in sponsorTypes {
            mData.append([])
        } // init data
        
       // mData[0] = self.data.filter{$0.type == "Diamond Sponsor"}
        
        for item in data {
            
            if(item.type == "Diamond Sponsor") {
                mData[0].append(item)
            }
            
            if(item.type == "Gold Sponsor") {
                mData[1].append(item)
            }
            
            if(item.type == "Silver Sponsor") {
                mData[2].append(item)
            }
        }
        
        self.allData = mData
    }
}


extension SponsorsVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
           return allData.count
       }
       
       func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
           return sponsorTypes[section]
       }
       
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return allData[section].count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "SponsorCell", for: indexPath) as! SponsorCell
           
           cell.sponserImage?.image = UIImage(named: "Speakers")
         
           
           cell.sponsorName?.text = allData[indexPath.section][indexPath.row].name
           cell.sponsorDetails?.text = allData[indexPath.section][indexPath.row].details
           return cell
       }
    
        func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
            guard let header = view as? UITableViewHeaderFooterView else { return }
            header.backgroundView?.backgroundColor = AppColors.primary
            header.textLabel?.font = UIFont.systemFont(ofSize: 13)
        }
       
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
        let data  = allData[indexPath.section][indexPath.row]
        
        if  data.name.count > 2 {
            
            speakerData = SpeakersModel(name: data.name, key: data.key, details: data.details, imageUrl: data.imageUrl)
            let speakerDetailsPopupViewController = SpeakerDetailsPopupViewController()
            speakerDetailsPopupViewController.modalPresentationStyle = .overFullScreen
            speakerDetailsPopupViewController.modalTransitionStyle = .crossDissolve
            present(speakerDetailsPopupViewController, animated: true, completion: nil)
            
        }
        
    }
    
}
