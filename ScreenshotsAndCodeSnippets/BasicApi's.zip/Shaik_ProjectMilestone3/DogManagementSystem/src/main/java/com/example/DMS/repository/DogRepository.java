package com.example.DMS.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.DMS.Models.Dog;

/**
 * @author s546901
 *
 */
public interface DogRepository extends CrudRepository<Dog, Integer> {

}
