package net.guides.springboot2.crud.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.guides.springboot2.crud.exception.ResourceNotFoundException;
import net.guides.springboot2.crud.model.Users;
import net.guides.springboot2.crud.repository.UsersRepository;

@RestController
@RequestMapping("/api/v1")
public class UserController {
	@Autowired
	private UserRepository userRepository;

	@GetMapping("/users")
	public List<Users> getAllUsers() {
		return userRepository.findAll();
	}

	@GetMapping("/users/{id}")
	public ResponseEntity<User> getUserById(@PathVariable(value = "id") Long userId)
			throws ResourceNotFoundException {
		Users user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));
		return ResponseEntity.ok().body(user);
	}

	@PostMapping("/users")
	public User createUsers(@Valid @RequestBody Users user) {
		return UsersRepository.save(Users);
	}

	@PutMapping("/users/{id}")
	public ResponseEntity<Users> updateUsers(@PathVariable(value = "id") Long UsersId,
			@Valid @RequestBody Users UsersDetails) throws ResourceNotFoundException {
		Users Users = UsersRepository.findById(UsersId)
				.orElseThrow(() -> new ResourceNotFoundException("Users not found for this id :: " + UsersId));

		Users.setEmailId(UsersDetails.getEmailId());
		Users.setLastName(UsersDetails.getLastName());
		Users.setFirstName(UsersDetails.getFirstName());
		final Users updatedUsers = UsersRepository.save(Users);
		return ResponseEntity.ok(updatedUsers);
	}

	@DeleteMapping("/users/{id}")
	public Map<String, Boolean> deleteUsers(@PathVariable(value = "id") Long UsersId)
			throws ResourceNotFoundException {
		Users Users = UsersRepository.findById(UsersId)
				.orElseThrow(() -> new ResourceNotFoundException("Users not found for this id :: " + UsersId));

		UsersRepository.delete(Users);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
