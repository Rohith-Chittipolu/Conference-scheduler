//
//  ViewController.swift
//  signUp
//
//  Created by Guntipally,Satwika Reddy on 10/14/22.
//

import UIKit
import SQLite3
var db: OpaquePointer?
class ViewController: UIViewController {
    @IBOutlet weak var userNameTF: UITextField!
    
    @IBOutlet weak var FirstNameTF: UITextField!
    @IBOutlet weak var emailIDTF: UITextField!
    @IBOutlet weak var LastNameTF: UITextField!
    
    
    @IBAction func signUpBTN(_ sender: Any) {
        let User_id = userNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let FIRST_NAME = FirstNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let EMAIL = emailIDTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let LAST_NAME = LastNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let PASSWORD = passwordTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let USER_TYPE = UserTypeTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        if (User_id?.isEmpty)! {
            print("User Name is Empty")
            return;
            
            
        }
        
        if (FIRST_NAME?.isEmpty)! {
            print("First Name is Empty")
            return;
            
            
        }
        if (EMAIL?.isEmpty)! {
            print("Email is Empty")
            return;
            
            
        }
        if (LAST_NAME?.isEmpty)! {
            print("Last Name is Empty")
            return;
            
            
        }
        if (PASSWORD?.isEmpty)! {
            print("Password is Empty")
            return;
            
            
        }
        if (USER_TYPE?.isEmpty)! {
            print("user Type is Empty")
            return;
            
            
        }
        
        var stmt: OpaquePointer?
        let insertQuery = "INSERT INTO USERDETAILS(User_id,EMAIL,PASSWORD,USER_TYPE,FIRST_NAME,LAST_NAME) VALUES (?,?,?,?,?,?)"
        if sqlite3_prepare(db, insertQuery, -1, &stmt, nil) != SQLITE_OK{
            
            print("Error binding query")
            
        }
        
        if sqlite3_bind_text(stmt, 1, User_id, -1, nil) != SQLITE_OK{
            print("Error binding user name")
            
        }
        
        if sqlite3_bind_text(stmt, 2,FIRST_NAME , -1, nil) != SQLITE_OK{
            print("Error binding first name")
            
        }
        
        if sqlite3_bind_text(stmt, 3,EMAIL , -1, nil) != SQLITE_OK{
            print("Error binding email id")
            
        }
        
        if sqlite3_bind_text(stmt, 4,PASSWORD , -1, nil) != SQLITE_OK{
            print("Error binding password")
            
        }
        
        if sqlite3_bind_text(stmt, 5,LAST_NAME , -1, nil) != SQLITE_OK{
            print("Error binding last name")
            
        }
        
        if sqlite3_bind_text(stmt, 6,USER_TYPE , -1, nil) != SQLITE_OK{
            print("Error binding user type")
            
        }
    }
    @IBOutlet weak var UserTypeTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("ConferenceDatabase.sqlite")
        //var db: OpaquePointer?
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK{
            
            print("error opening database")
            return
        }
        let createTableQuery = "CREATE TABLE IF NOT EXISTS USERDETAILS(User_id TEXT PRIMARY KEY , EMAIL TEXT , PASSWORD TEXT , USER_TYPE TEXT , FIRST_NAME TEXT , LAST_NAME TEXT) "
        
       if sqlite3_exec(db, createTableQuery, nil, nil, nil) != SQLITE_OK{
            print("Error creating table")
        return
            
        }
        print("table created successfully")
    }
    



}

