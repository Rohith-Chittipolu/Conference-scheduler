 
import Foundation

class UserDefaultsManager  {
    
    static  let shared =  UserDefaultsManager()
     
    func clearUserDefaults() {
        
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()

            dictionary.keys.forEach
            {
                key in   defaults.removeObject(forKey: key)
            }
    }
    
    func isLoggedIn() -> Bool{
        
        let email = getEmail()
        
        if(email.isEmpty) {
            return false
        }else {
           return true
        }
      
    }
     
    func getEmail()-> String {
        
        let email = UserDefaults.standard.string(forKey: "email") ?? ""
        
        print(email)
        return email
    }
    
    func getFirebaseToken()-> String {
        let token = UserDefaults.standard.string(forKey: "token") ?? "aaabbbccc"
        print(token)
        return token
    }
    
    
    func saveFirebaseToken(token:String) {
        
        UserDefaults.standard.setValue(token, forKey: "token")
    }
    
    
    
    func getKey()-> String {
        let documentID = UserDefaults.standard.string(forKey: "documentID") ?? ""
        return documentID
    }
    
    func getName()-> String {
       return UserDefaults.standard.string(forKey: "name") ?? ""
    }

    func getUserType()-> UserType {
        if(UserDefaults.standard.string(forKey: "userType") == UserType.STUDENT.rawValue)  {
            return .STUDENT
        }else if(UserDefaults.standard.string(forKey: "userType") == UserType.SUPER_ADMIN.rawValue)  {
            return .SUPER_ADMIN
        }else {
            return .ADMIN
        }
    }

    func saveData(documentID:String,name:String,email:String,userType:String) {
        UserDefaults.standard.setValue(name, forKey: "name")
        UserDefaults.standard.setValue(email, forKey: "email")
        UserDefaults.standard.setValue(userType, forKey: "userType")
        UserDefaults.standard.setValue(documentID, forKey: "documentID")
        UserDefaults.standard.setValue(Date(), forKey: "lastLoginTime")
    }
    
    func updateName(name:String) {
        UserDefaults.standard.setValue(name, forKey: "name")
    }
  
    
}
