import UIKit
 
class GlobalDatePickerVC: UIViewController {
    
   @objc var completionHandler:((Date,String) -> Void)?
    
    @IBOutlet weak var pickerView: UIDatePicker!
   
   @objc public var maxDate = Date()
   @objc public var minDate = Date()
     
     let dateFormatter = DateFormatter()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        pickerView.datePickerMode = .dateAndTime
        pickerView.sizeToFit()
       
        if #available(iOS 13.4, *) {
            pickerView.preferredDatePickerStyle = UIDatePickerStyle.wheels
        } else {
            // Fallback on earlier versions
        }
        
        let calendar = Calendar(identifier: .gregorian)
        var comps = DateComponents()
        comps.year = +100
        let minDate = calendar.date(byAdding: comps, to: Date())
        
        
        pickerView.maximumDate = minDate
        pickerView.minimumDate = Date()

    }
    
    @IBAction func onDone(_ sender: Any) {
        
       
        self.dismiss(animated: true, completion: nil)
       
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
       
        completionHandler?(pickerView.date,dateFormatter.string(from: pickerView.date))
    
    }
    
    @IBAction func onClose(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
