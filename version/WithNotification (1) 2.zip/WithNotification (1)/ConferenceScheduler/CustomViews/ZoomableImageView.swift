 
import UIKit

class ZoomableImageView: UIImageView {
    
    private var isZoomed = false
    private let minZoomScale: CGFloat = 1.0
    private let maxZoomScale: CGFloat = 4.0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupGestureRecognizers()
        contentMode = .scaleAspectFit
        isUserInteractionEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupGestureRecognizers()
        contentMode = .scaleAspectFit
        isUserInteractionEnabled = true
    }
    
    private func setupGestureRecognizers() {
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap))
        doubleTapGesture.numberOfTapsRequired = 2
        addGestureRecognizer(doubleTapGesture)
        
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch))
        addGestureRecognizer(pinchGesture)
    }
    
    @objc private func handleDoubleTap() {
        zoomOut()
//        if isZoomed {
//            zoomOut()
//        } else {
//            zoomIn()
//        }
//        isZoomed = !isZoomed
    }
    
    @objc private func handlePinch(sender: UIPinchGestureRecognizer) {
        guard let view = sender.view else { return }
        if sender.state == .began || sender.state == .changed {
            let scale = sender.scale
            view.transform = view.transform.scaledBy(x: scale, y: scale)
            sender.scale = 1.0
        } else if sender.state == .ended {
            let currentScale = view.frame.size.width / view.bounds.size.width
            let newScale = currentScale * sender.scale
            if newScale < minZoomScale {
                zoomOut()
            } else if newScale > maxZoomScale {
                zoomIn()
            }
        }
    }
    
    private func zoomIn() {
        UIView.animate(withDuration: 0.3) {
            let scale = self.maxZoomScale / self.bounds.size.width
            let translateX = (self.bounds.size.width - self.bounds.size.width * scale) / 2.0
            let translateY = (self.bounds.size.height - self.bounds.size.height * scale) / 2.0
            let transform = CGAffineTransform(scaleX: scale, y: scale).translatedBy(x: translateX, y: translateY)
            self.transform = transform
        }
    }
    
    private func zoomOut() {
        UIView.animate(withDuration: 0.3) {
            self.transform = CGAffineTransform.identity
        }
    }
}
