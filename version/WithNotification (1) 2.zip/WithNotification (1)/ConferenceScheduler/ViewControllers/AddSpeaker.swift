
import UIKit

class AddSpeaker: UIViewController {

    @IBOutlet weak var speaker: UITextField!
    @IBOutlet weak var aboutSpeaker: UITextField!
    @IBOutlet weak var selectedImage: UIImageView!
    var photoSelected = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
  
 
    @IBAction func onPhoto(_ sender: Any) {
        self.view.endEditing(true)
        let sourceType: UIImagePickerController.SourceType = .photoLibrary

        presentImagePickerController(sourceType: sourceType) { (selectedImage) in
            
            if let image = selectedImage {
                self.selectedImage.image = image
                self.photoSelected = true
            }
        }
    }
    @IBAction func onAddSpeaker(_ sender: Any) {
        
        
        self.view.endEditing(true)
        
       
        if(self.speaker.text!.isEmpty) {
            showAlert(message: "Please enter speaker name")
            return
        }
        
        if !(self.speaker.text!.isValidName) {
            showAlertAnyWhere(message: "Please enter valid speaker name.")
            return
        }
        
        if(self.aboutSpeaker.text!.isEmpty) {
            showAlert(message: "Please enter speaker details")
            return
        }
        
         
        if(!photoSelected) {
            showAlert(message: "Please add speaker photo")
            return
        }
        
        FireStoreManager.shared.saveImage(image: selectedImage.image!) { imageUrl in
             
         
            FireStoreManager.shared.addSpeaker(name: self.speaker.text!, details: self.aboutSpeaker.text!, url: imageUrl) {
                self.navigationController?.popViewController(animated: true)
            }
         
        }
    }
    
    
}
