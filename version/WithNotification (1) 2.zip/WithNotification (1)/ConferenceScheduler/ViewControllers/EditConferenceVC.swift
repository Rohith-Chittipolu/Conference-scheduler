import UIKit

class EditConferenceVC: UIViewController {

    @IBOutlet weak var selectedImage: UIImageView!
    @IBOutlet weak var conferenceName: UITextField!
    var newPhotoSelected = false
    var conferenceId = ""
    var eventImageUrl = ""
    var name = ""
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.conferenceName.text = name
        
        if let imageURL = URL(string: self.eventImageUrl), self.eventImageUrl.count > 5 {
            let session = URLSession.shared
            let task = session.dataTask(with: imageURL) { data, response, error in
                if let data = data, let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.selectedImage.image = image
                    }
                }
            }
            task.resume()
        }
    }
 
    @IBAction func onPhoto(_ sender: Any) {
        self.view.endEditing(true)
        let sourceType: UIImagePickerController.SourceType = .photoLibrary

        presentImagePickerController(sourceType: sourceType) { (selectedImage) in
            if let image = selectedImage {
                self.selectedImage.image = image
                self.newPhotoSelected = true
            }
        }
    }
    @IBAction func onUpdate(_ sender: Any) {
        
        self.view.endEditing(true)
        
        if(self.conferenceName.text!.isEmpty) {
            showAlert(message: "Please enter conference Name")
            return
        }
         
        
        if( (newPhotoSelected == false) && (self.conferenceName.text == name) ) {
            
            self.dismiss(animated: true)
            
        }else {
            
            if(newPhotoSelected) {
                
                FireStoreManager.shared.saveImage(image: selectedImage.image!) { imageUrl in
                     
                    FireStoreManager.shared.updateConference(key: self.conferenceId, name: self.conferenceName.text!, url: imageUrl) {
        
                        self.dismiss(animated: true)
                    }
                }
                
            }else {
                
                FireStoreManager.shared.updateConference(key: self.conferenceId, name: self.conferenceName.text!, url: eventImageUrl) {

                    self.dismiss(animated: true)
                }
                
            }
        }
         
        
    }
    
   
    @IBAction func onDelete(_ sender: Any) {
        
        showConfirmationAlert(message: "Are you sure you want to delete?", yesHandler: { [weak self] _ in
            
            FireStoreManager.shared.deleteConference(key: self!.conferenceId) {

                 self?.dismiss(animated: true, completion: nil)
            }
           
        })
    }
    
}
