import UIKit

 
class ScheduleVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var topTitle: UILabel!
    @IBOutlet weak var noEventImage: UIImageView!
    @IBOutlet weak var noConferenceLabel: UILabel!
    @IBOutlet weak var eventView: UIView!
    @IBOutlet weak var eventImageView: UIImageView!
    var haveEvents = false
    var conferenceId = ""
    var eventImageUrl = ""
    var evets = [EventModel]()
    @IBOutlet weak var eventName: UILabel!
    
    func setUI(){
        
        if(haveEvents) {
            
            self.topTitle.isHidden = false
            self.noEventImage.isHidden = true
            noConferenceLabel.isHidden = true
            self.eventView.isHidden = false
            
        }else {
            self.topTitle.isHidden = true
            self.noEventImage.isHidden = false
            noConferenceLabel.isHidden = false
            self.eventView.isHidden = true
        }
    }
     
    override func viewDidLoad() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.registerCells([EventCell.self])
      
   
    }
    
    override func viewWillAppear(_ animated: Bool) {
    
        self.setUI()
        
        self.startFetchData()
        
    }
    
    
    func startFetchData()  {
        
        FireStoreManager.shared.getConferences { confrences in
            
            if(confrences.count == 0) {
                self.haveEvents = false
                self.setUI()
                self.conferenceId = ""
            }else {
                self.haveEvents = true
                self.setUI()
                self.eventName.text = confrences.first?.name ?? ""
                self.conferenceId = confrences.first?.key ?? ""
                self.eventImageUrl = confrences.first?.imageUrl ?? ""
                
                
                if let imageURL = URL(string: self.eventImageUrl), self.eventImageUrl.count > 5 {
                    let session = URLSession.shared
                    let task = session.dataTask(with: imageURL) { data, response, error in
                        if let data = data, let image = UIImage(data: data) {
                            DispatchQueue.main.async {
                                self.eventImageView.image = image
                            }
                        }
                    }
                    task.resume()
                }
                
                
                DispatchQueue.main.async {
                    self.getEvents()
                }
                
            }
        }
    }
    
    func getEvents() {

        if(conferenceId == "") { // empty list and realaod data
            
            self.evets.removeAll()
            self.tableView.reloadData()
        }else {
            
        
            FireStoreManager.shared.getScheduledEvents(conferenceId: conferenceId) { evets in
                self.evets = evets
                self.tableView.reloadData()
                
//                if(evets.isEmpty) {
//                    self.showAlert(message: "No Event Scheduled")
//                }
            }
           
            
        }
        
       
    }
   
    

}



extension ScheduleVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.evets.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier:  String(describing: EventCell.self), for: indexPath) as! EventCell
        
        cell.setData(evet: evets[indexPath.row])
        
        if(UserDefaultsManager.shared.getUserType() == .STUDENT) {
            cell.addButton.isHidden = false
            cell.addButton.tag = indexPath.row
            cell.addButton.setImage(UIImage(systemName: "minus.square"), for: .normal)
            cell.addButton.addTarget(self, action: #selector(self.removeSchedule(_:)), for: .touchUpInside)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        DispatchQueue.main.async {
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "EventDetailsVC") as! EventDetailsVC
            vc.modalPresentationStyle = .popover
            vc.event = self.evets[indexPath.row]
          //  vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true)
            
             
        }
           
         
        
    }
    

    
    @objc func removeSchedule(_ sender: UIButton) {
        let row = sender.tag
        let event = evets[row]
 
        
        showConfirmationAlert(message: "Are you sure you want to remove this schedule?", yesHandler: { [weak self] _ in
            
            
            DispatchQueue.main.async {
                
                FireStoreManager.shared.removeSchedule(event: event) {
                   
                    DispatchQueue.main.async {
                        self!.getEvents()
                    }
                    
                }
           
            }
         })
        
    }
    
    
}
