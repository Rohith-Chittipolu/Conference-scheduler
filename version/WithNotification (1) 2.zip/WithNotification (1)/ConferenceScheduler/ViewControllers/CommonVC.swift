 
import UIKit

class CommonVC: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var image: UIImageView!
    
    
    
    var imageName = ""
    var titleString = ""
    
    override func viewDidLoad() {
        self.image.image = UIImage(named: imageName)
        self.titleLabel.text = titleString
    }

}
