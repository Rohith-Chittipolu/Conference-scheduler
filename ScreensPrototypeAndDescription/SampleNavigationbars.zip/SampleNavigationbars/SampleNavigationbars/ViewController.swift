//
//  ViewController.swift
//  SampleNavigationbars
//
//  Created by Sunkireddy,Aakanksha Reddy on 9/30/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = .systemPink
        let button = UIButton(frame: CGRect(x: 0, y:90, width:400 ,height:50))
        view.addSubview(button)
        
        button.backgroundColor = .systemMint
        button.setTitle("Conference-Schedular", for: .normal)
        self.navigationItem.title = "Conference-Schedular"
        
        let image = UIImage(named: "meeting")
        navigationItem.titleView = UIImageView(image: image)
        configureItems()
    }
    
    private func configureItems(){
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: nil)
        
    }
    
}
