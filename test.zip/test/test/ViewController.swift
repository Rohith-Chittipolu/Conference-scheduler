//
//  ViewController.swift
//  test
//
//  Created by Shaik,Abdul Khayyam Sahib on 10/3/22.
//

import UIKit
import Parse

class ViewController: UIViewController {

    @IBOutlet weak var txtUsernameSignin: UITextField!
    @IBOutlet weak var txtPasswordSignin: UITextField!
    
   
    @IBAction func indicatorLogin(_ sender: Any) {
        
        PFUser.logInWithUsername(inBackground: self.txtUsernameSignin.text!, password: self.txtPasswordSignin.text!) {
                  (user: PFUser?, error: Error?) -> Void in
                  if user != nil {
                    self.displayAlert(withTitle: "Login Successful", message: "")
                  } else {
                    self.displayAlert(withTitle: "Error", message: error!.localizedDescription)
                  }
                }
    }
    @IBOutlet weak var txtUsernameSignup: UITextField!
   
    @IBOutlet weak var displayAlert: UILabel!
    @IBOutlet weak var txtPasswordSignup: UITextField!
    @IBAction func indicatorSignup(_ sender: Any) {
        
        let user = PFUser()
                user.username = self.txtUsernameSignup.text
                user.password = self.txtPasswordSignup.text
                
               // self.indicatorSignup.startAnimating()
                user.signUpInBackground {(succeeded: Bool, error: Error?) -> Void in
                  //  self.indicatorSignup.stopAnimating()
                    if let error = error {
                        self.displayAlert(withTitle: "Error", message: error.localizedDescription)
                    } else {
                        self.displayAlert(withTitle: "Success", message: "Account has been successfully created")
                    }
                }
        
        
    }
    
    func displayAlert(withTitle title: String, message: String) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default)
            alert.addAction(okAction)
            self.present(alert, animated: true)
        }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    


}

